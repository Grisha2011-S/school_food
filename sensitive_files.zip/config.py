﻿# instance/config.py — ПРИМЕР (замените значения на реальные после загрузки)
SECRET_KEY = 'replace-this-with-a-random-secret'
DATABASE_URI = 'sqlite:///../instance.sqlite3'  # пример
# Добавьте здесь другие переменные, которые ваше приложение ожидает
